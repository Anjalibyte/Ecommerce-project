package com.shop;
import jakarta.servlet.http.HttpSession;
import java.math.BigDecimal;
import java.util.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class ApiController {
  private final ShopDao dao;
  public ApiController(ShopDao dao) { this.dao = dao; }
  private Integer uid(HttpSession s) { return (Integer) s.getAttribute("uid"); }

  @GetMapping("/products")
  public List<Map<String,Object>> all() { return dao.products(BigDecimal.ZERO, new BigDecimal("1000000"), ""); }

  @GetMapping("/products/{id}")
  public ResponseEntity<?> one(@PathVariable int id) {
    Map<String,Object> p = dao.product(id);
    return p == null ? ResponseEntity.notFound().build() : ResponseEntity.ok(p);
  }
  @GetMapping("/cart")
  public ResponseEntity<?> cart(HttpSession s) {
    return uid(s) == null ? ResponseEntity.status(401).body("Login first") : ResponseEntity.ok(dao.cart(uid(s)));
  }
  @PostMapping("/cart")
  public ResponseEntity<?> add(@RequestBody Map<String,Integer> body, HttpSession s) {
    if (uid(s) == null) return ResponseEntity.status(401).body("Login first");
    dao.addToCart(uid(s), body.get("productId"));
    return ResponseEntity.ok("Added");
  }
  @DeleteMapping("/cart/{id}")
  public ResponseEntity<?> remove(@PathVariable int id, HttpSession s) {
    if (uid(s) == null) return ResponseEntity.status(401).body("Login first");
    dao.removeCart(id, uid(s));
    return ResponseEntity.ok("Removed");
  }
  @PostMapping("/checkout")
  public ResponseEntity<?> checkout(HttpSession s) {
    if (uid(s) == null) return ResponseEntity.status(401).body("Login first");
    List<Map<String,Object>> c = dao.cart(uid(s));
    if (c.isEmpty()) return ResponseEntity.badRequest().body("Cart empty");
    BigDecimal t = BigDecimal.ZERO;
    for (Map<String,Object> r : c) t = t.add((BigDecimal) r.get("subtotal"));
    dao.placeOrder(uid(s), t, "API order");
    return ResponseEntity.ok("Order placed. Total: " + t);
  }
}
