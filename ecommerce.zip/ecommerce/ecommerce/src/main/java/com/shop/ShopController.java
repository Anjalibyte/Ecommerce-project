package com.shop;
import jakarta.servlet.http.HttpSession;
import java.math.BigDecimal;
import java.util.*;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class ShopController {
  private final ShopDao dao;
  private final BCryptPasswordEncoder enc = new BCryptPasswordEncoder();
  public ShopController(ShopDao dao) { this.dao = dao; }

  private Integer uid(HttpSession s) { return (Integer) s.getAttribute("uid"); }
  private BigDecimal total(List<Map<String,Object>> cart) {
    BigDecimal t = BigDecimal.ZERO;
    for (Map<String,Object> r : cart) t = t.add((BigDecimal) r.get("subtotal"));
    return t;
  }

  @GetMapping("/")
  public String home(Model m) {
    m.addAttribute("products", dao.products(BigDecimal.ZERO, new BigDecimal("1000000"), "").stream().limit(4).toList());
    return "home";
  }

  // ---------- Signup / Login ----------
  @GetMapping("/signup") public String signupForm() { return "signup"; }
  @PostMapping("/signup")
  public String signup(@RequestParam String username, @RequestParam String password,
                       @RequestParam String email, Model m) {
    try {
      dao.createUser(username.trim(), enc.encode(password), email);
      return "redirect:/login?registered";
    } catch (DuplicateKeyException e) {
      m.addAttribute("error", "Username already taken");
      return "signup";
    }
  }
  @GetMapping("/login") public String loginForm() { return "login"; }
  @PostMapping("/login")
  public String login(@RequestParam String username, @RequestParam String password,
                      HttpSession s, Model m) {
    Map<String,Object> u = dao.findUser(username.trim());
    if (u != null && enc.matches(password, (String) u.get("password"))) {
      s.setAttribute("uid", ((Number) u.get("id")).intValue());
      s.setAttribute("user", u.get("username"));
      return "redirect:/products";
    }
    m.addAttribute("error", "Invalid username or password");
    return "login";
  }
  @GetMapping("/logout")
  public String logout(HttpSession s) { s.invalidate(); return "redirect:/"; }

  // ---------- Products ----------
  @GetMapping("/products")
  public String products(@RequestParam(defaultValue = "0") BigDecimal min,
                         @RequestParam(defaultValue = "1000000") BigDecimal max,
                         @RequestParam(defaultValue = "") String category, Model m) {
    m.addAttribute("products", dao.products(min, max, category));
    m.addAttribute("categories", dao.categories());
    m.addAttribute("min", min); m.addAttribute("max", max); m.addAttribute("category", category);
    return "products";
  }
  @GetMapping("/products/{id}")
  public String details(@PathVariable int id, Model m) {
    Map<String,Object> p = dao.product(id);
    if (p == null) return "redirect:/products";
    m.addAttribute("p", p);
    return "product-details";
  }

  // ---------- Cart ----------
  @PostMapping("/cart/add/{id}")
  public String add(@PathVariable int id, HttpSession s) {
    if (uid(s) == null) return "redirect:/login";
    dao.addToCart(uid(s), id);
    return "redirect:/cart";
  }
  @GetMapping("/cart")
  public String cart(HttpSession s, Model m) {
    if (uid(s) == null) return "redirect:/login";
    List<Map<String,Object>> c = dao.cart(uid(s));
    m.addAttribute("items", c); m.addAttribute("total", total(c));
    return "cart";
  }
  @PostMapping("/cart/update/{id}")
  public String update(@PathVariable int id, @RequestParam int quantity, HttpSession s) {
    if (uid(s) == null) return "redirect:/login";
    dao.updateQty(id, uid(s), quantity);
    return "redirect:/cart";
  }
  @PostMapping("/cart/remove/{id}")
  public String remove(@PathVariable int id, HttpSession s) {
    if (uid(s) == null) return "redirect:/login";
    dao.removeCart(id, uid(s));
    return "redirect:/cart";
  }

  // ---------- Checkout ----------
  @GetMapping("/checkout")
  public String checkoutForm(HttpSession s, Model m) {
    if (uid(s) == null) return "redirect:/login";
    List<Map<String,Object>> c = dao.cart(uid(s));
    if (c.isEmpty()) return "redirect:/cart";
    m.addAttribute("total", total(c));
    return "checkout";
  }
  @PostMapping("/checkout")
  public String pay(@RequestParam String cardName, @RequestParam String cardNumber,
                    @RequestParam String expiry, @RequestParam String cvv,
                    HttpSession s, Model m) {
    if (uid(s) == null) return "redirect:/login";
    List<Map<String,Object>> c = dao.cart(uid(s));
    BigDecimal t = total(c);
    m.addAttribute("total", t);
    if (!cardNumber.replaceAll("\\s", "").matches("\\d{16}")) { m.addAttribute("error", "Card number must be 16 digits"); return "checkout"; }
    if (!expiry.matches("(0[1-9]|1[0-2])/\\d{2}")) { m.addAttribute("error", "Expiry must be MM/YY"); return "checkout"; }
    if (!cvv.matches("\\d{3,4}")) { m.addAttribute("error", "CVV must be 3 or 4 digits"); return "checkout"; }
    if (c.isEmpty()) return "redirect:/cart";
    dao.placeOrder(uid(s), t, cardName);   // card number/CVV are NOT stored
    return "success";
  }
}
