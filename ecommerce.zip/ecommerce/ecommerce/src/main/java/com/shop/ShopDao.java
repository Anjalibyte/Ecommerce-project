package com.shop;
import java.math.BigDecimal;
import java.util.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class ShopDao {
  private final JdbcTemplate jdbc;
  public ShopDao(JdbcTemplate jdbc) { this.jdbc = jdbc; }

  public void createUser(String u, String hash, String email) {
    jdbc.update("INSERT INTO users(username,password,email) VALUES(?,?,?)", u, hash, email);
  }
  public Map<String,Object> findUser(String u) {
    List<Map<String,Object>> l = jdbc.queryForList("SELECT * FROM users WHERE username=?", u);
    return l.isEmpty() ? null : l.get(0);
  }
  public List<Map<String,Object>> products(BigDecimal min, BigDecimal max, String cat) {
    if (cat == null || cat.isBlank())
      return jdbc.queryForList("SELECT * FROM products WHERE price BETWEEN ? AND ? ORDER BY price", min, max);
    return jdbc.queryForList("SELECT * FROM products WHERE price BETWEEN ? AND ? AND category=? ORDER BY price", min, max, cat);
  }
  public List<String> categories() {
    return jdbc.queryForList("SELECT DISTINCT category FROM products", String.class);
  }
  public Map<String,Object> product(int id) {
    List<Map<String,Object>> l = jdbc.queryForList("SELECT * FROM products WHERE id=?", id);
    return l.isEmpty() ? null : l.get(0);
  }
  public void addToCart(int uid, int pid) {
    jdbc.update("INSERT INTO cart(user_id,product_id,quantity) VALUES(?,?,1) ON DUPLICATE KEY UPDATE quantity=quantity+1", uid, pid);
  }
  public List<Map<String,Object>> cart(int uid) {
    return jdbc.queryForList("SELECT c.id, c.quantity, p.name, p.price, p.image_url, p.price*c.quantity AS subtotal "
      + "FROM cart c JOIN products p ON p.id=c.product_id WHERE c.user_id=?", uid);
  }
  public void updateQty(int id, int uid, int q) {
    if (q <= 0) removeCart(id, uid);
    else jdbc.update("UPDATE cart SET quantity=? WHERE id=? AND user_id=?", q, id, uid);
  }
  public void removeCart(int id, int uid) {
    jdbc.update("DELETE FROM cart WHERE id=? AND user_id=?", id, uid);
  }
  @Transactional
  public void placeOrder(int uid, BigDecimal total, String nameOnCard) {
    jdbc.update("INSERT INTO orders(user_id,total,name_on_card) VALUES(?,?,?)", uid, total, nameOnCard);
    jdbc.update("DELETE FROM cart WHERE user_id=?", uid);
  }
}
